
# import required module
from playsound import playsound

# for playing note.wav file


def Digitalsound():
    print('playing sound Digitalsound')
    playsound('E:/Chrome Downloads/hackocbit-main/Backend/media/buzzer.wav')


def Buzzersound():
    playsound('E:/Chrome Downloads/hackocbit-main/Backend/media/buzzer.wav')


print('playing sound using  playsound')
# Digitalsound()
